import re

header = {
	
}

def getUrl(arg,argLen,clip,dst,dataSource):
	data = dict()
	data["urls"] = list()
	data["names"] = list()

	if data["urls"]:
		return data
